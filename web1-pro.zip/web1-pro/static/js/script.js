let isDataProcessed = false;

// Handle data processing
function processData() {
    const inputField = document.getElementById("inputField").value.trim();
    if (!inputField) {
        alert("Data cannot be empty! Please enter valid data.");
        return;
    }
    alert("Data processed successfully!");
    isDataProcessed = true; // Mark data as processed
}

// Warn about unprocessed data before leaving the page
window.addEventListener("beforeunload", (event) => {
    if (!isDataProcessed) {
        event.returnValue = "You have unprocessed data. Are you sure you want to leave?";
    }
});

// Dynamically calculate total marks
function calculateTotal() {
    const mark1 = parseFloat(document.getElementById('mark1').value) || 0;
    const mark2 = parseFloat(document.getElementById('mark2').value) || 0;
    const mark3 = parseFloat(document.getElementById('mark3').value) || 0;

    const total = mark1 + mark2 + mark3;
    document.getElementById('total').value = total.toFixed(2); // Format to two decimal places
}

// Form validation
function validateForm() {
    const name = document.getElementById('name').value.trim();
    const studentClass = document.getElementById('class').value.trim();

    if (!name) {
        alert("Name is required.");
        return false;
    }

    if (!studentClass || isNaN(studentClass) || Number(studentClass) <= 0 || Number(studentClass) >= 12) {
        alert("Class must be a positive number less than 12.");
        return false;
    }

    return true; // All validations pass
}

// Confirm deletion
function confirmDelete() {
    return confirm("Are you sure you want to delete this student record?");
}

// Search students by class
// Validate class input and fetch students
function validateClassAndFetch() {
    const classInput = document.getElementById('class-input');
    const errorElement = document.getElementById('class-error');
    const studentDropdown = document.getElementById('student-dropdown');
    const marksDisplay = document.getElementById('marks-display');

    const classValue = classInput.value.trim();

    // Validate the input
    if (!classValue || isNaN(classValue) || Number(classValue) <= 0 || Number(classValue) >= 13) {
        errorElement.textContent = "Please enter a positive number less than 13.";
        studentDropdown.innerHTML = '<option value="">Invalid class</option>';
        marksDisplay.innerHTML = '';
        return;
    }

    // Clear error message
    errorElement.textContent = '';
    fetchStudents(classValue);
}

// Fetch students by class
function fetchStudents(classNumber) {
    const studentDropdown = document.getElementById('student-dropdown');
    const marksDisplay = document.getElementById('marks-display');

    fetch(`/search?class=${classNumber}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Error: ${response.statusText}`);
            }
            return response.json();
        })
        .then(students => {
            if (students.length === 0) {
                studentDropdown.innerHTML = '<option value="">No students found</option>';
            } else {
                studentDropdown.innerHTML = '<option value="">Select a student</option>';
                students.forEach(student => {
                    const option = document.createElement('option');
                    option.value = student.id; // Use rollno or ID
                    option.textContent = student.name; // Student name
                    studentDropdown.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error('Error fetching students:', error);
            studentDropdown.innerHTML = '<option value="">Failed to load students</option>';
        });

    marksDisplay.innerHTML = ''; // Clear marks display
}

// Fetch marks for the selected student
function fetchMarks() {
    const rollno = document.getElementById('student-dropdown').value;
    const marksDisplay = document.getElementById('marks-display');

    if (!rollno) {
        marksDisplay.innerHTML = '<p>Please select a student</p>';
        return;
    }

    fetch(`/get-marks?rollno=${rollno}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Error: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                marksDisplay.innerHTML = `<p>${data.error}</p>`;
            } else {
                marksDisplay.innerHTML = `
                    <h3>Marks for ${data.name}</h3>
                    <p>Class: ${data.class}</p>
                    <p>Mark 1: ${data.marks.mark1}</p>
                    <p>Mark 2: ${data.marks.mark2}</p>
                    <p>Mark 3: ${data.marks.mark3}</p>
                    <p><strong>Total: ${data.marks.total}</strong></p>
                `;
            }
        })
        .catch(error => {
            console.error('Error fetching marks:', error);
            marksDisplay.innerHTML = '<p>Failed to load marks</p>';
        });
}
 
