from flask import Flask, render_template, request, redirect, url_for, jsonify  # type: ignore
from flask_mysqldb import MySQL  # type: ignore

app = Flask(__name__)

# MySQL configurations
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'  # Replace with your MySQL username
app.config['MYSQL_PASSWORD'] = 'Pandiyarajan_21'  # Replace with your MySQL password
app.config['MYSQL_DB'] = 'student_management'

mysql = MySQL(app)

@app.route('/')
def index():
    try:
        # Fetch all student data
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM student")
        students = cur.fetchall()
        cur.close()
    except Exception as e:
        return f"An error occurred: {e}", 500
    
    return render_template('index.html', students=students)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        try:
            rollno = request.form['rollno']
            name = request.form['name']
            student_class = int(request.form['class'])
            mark1 = int(request.form['mark1'])
            mark2 = int(request.form['mark2'])
            mark3 = int(request.form['mark3'])
            total = mark1 + mark2 + mark3
            
            # Insert into database
            cur = mysql.connection.cursor()
            cur.execute(
                "INSERT INTO student(rollno,name, class, mark1, mark2, mark3, total) VALUES(%s,%s, %s, %s, %s, %s, %s)", 
                (rollno,name, student_class, mark1, mark2, mark3, total)
            )
            mysql.connection.commit()
            cur.close()
        except Exception as e:
            return f"An error occurred: {e}", 500

        return redirect(url_for('index'))
    
    return render_template('add.html')

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM student WHERE id = %s", (id,))
        student = cur.fetchone()
    except Exception as e:
        return f"An error occurred: {e}", 500

    if request.method == 'POST':
        try:
            rollno = request.form['rollno']
            name = request.form['name']
            student_class = int(request.form['class'])
            mark1 = int(request.form['mark1'])
            mark2 = int(request.form['mark2'])
            mark3 = int(request.form['mark3'])
            total = mark1 + mark2 + mark3
            
            # Update the database
            cur.execute(
                "UPDATE student SET rollno = %s, name = %s, class = %s, mark1 = %s, mark2 = %s, mark3 = %s, total = %s WHERE id = %s", 
                (rollno,name, student_class, mark1, mark2, mark3, total, id)
            )
            mysql.connection.commit()
            cur.close()
        except Exception as e:
            return f"An error occurred: {e}", 500

        return redirect(url_for('index'))
    
    return render_template('edit.html', student=student)

@app.route('/delete/<int:id>')
def delete(id):
    try:
        cur = mysql.connection.cursor()
        cur.execute("DELETE FROM student WHERE id = %s", (id,))
        mysql.connection.commit()
        cur.close()
    except Exception as e:
        return f"An error occurred: {e}", 500
    
    return redirect(url_for('index'))

@app.route('/search', methods=['GET'])
def search_students():
    class_name = request.args.get('class')
    
    # Backend validation for class input
    try:
        class_number = int(class_name)
        if class_number < 1 or class_number >= 13:
            return jsonify({"error": "Class must be a positive number less than 13"}), 400
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid class number"}), 400

    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, name FROM student WHERE class = %s", (class_number,))
        students = cur.fetchall()
        cur.close()
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    return jsonify([
        {"id": student[0], "name": student[1]} for student in students
    ])




@app.route('/get-marks', methods=['GET'])
def get_student_marks():
    rollno = request.args.get('rollno')
    if not rollno:
        return jsonify({"error": "Roll number parameter is required"}), 400

    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT name, class, mark1, mark2, mark3 FROM student WHERE id = %s", (rollno,))
        student = cur.fetchone()
        cur.close()

        if not student:
            return jsonify({"error": "Student not found"}), 404
        
        return jsonify({
            "name": student[0],
            "class": student[1],
            "marks": {
                "mark1": student[2],
                "mark2": student[3],
                "mark3": student[4],
                "total": student[2] + student[3] + student[4]
            }
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)